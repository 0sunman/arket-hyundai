import favorites from './favourite';
import {combineReducers} from 'redux';

const rootReducer = combineReducers({
    favorites
})

export default rootReducer;