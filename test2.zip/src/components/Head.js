const Head = () =>{
    return (<>
      <title>의류 모두보기 - ARKET KR</title>
      <script type="text/javascript" src="https://image.thehyundai.com/arket/js/jquery-migrate.min.js"></script>
      <script type="text/javascript" src="https://image.thehyundai.com/arket/org/etc/designs/hm/clientlibs/shared/jquery.min.98d49f2a9477a5d4f9edef7b7e9698b1.js"></script>
      <script type="text/javascript" src="https://image.thehyundai.com/arket/org/etc/designs/appeaser/p11/pattern-lib/frontend/js/modernizr-custom.min.js"></script>
      <script type="text/javascript" src="https://image.thehyundai.com/arket/org/metrics/default/touchpoint.js"></script>
      <script type="text/javascript" src="https://image.thehyundai.com/arket/org/etc/designs/appeaser/p11/clientlibs/application.min.73b337f60c6d73af4c93d85989b79c31.js"></script>
      <script type="text/javascript" src="https://image.thehyundai.com/arket/org/etc/designs/appeaser/shared/clientlibs/components.min.0ff734763f97062b81ea61876bc97b89.js"></script>
      <script type="text/javascript" src="https://image.thehyundai.com/arket/org/etc/designs/appeaser/p11/pattern-lib/frontend.min.53fbce400c01c000a192f9a286ec0c06.js"></script>
      <script type="text/javascript" src="https://image.thehyundai.com/arket/js/jquery.cookie.js"></script>
      <script type="text/javascript" src="https://image.thehyundai.com/arket/js/frontend.renew.js?ver=11111730"></script>
      <script type="text/javascript" src="https://image.thehyundai.com/arket/js/hd.common.js?ver=11111730"></script>

    
    </>)
}

export default Head;